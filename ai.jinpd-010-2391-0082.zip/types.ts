export enum Difficulty {
  EASY = 'Easy',
  MEDIUM = 'Medium',
  HARD = 'Hard',
}

export interface CellData {
  row: number;
  col: number;
  value: number; // 0 for empty
  isFixed: boolean; // True if part of the initial puzzle
  notes: Set<number>;
  isError: boolean;
  isHinted?: boolean;
}

export type Board = CellData[][];

export interface HintResponse {
  row: number;
  col: number;
  value: number;
  explanation: string;
}
