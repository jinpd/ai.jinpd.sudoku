import React from 'react';
import { Pencil, Undo2, Eraser, Lightbulb, RefreshCw, Trophy } from 'lucide-react';

interface ControlsProps {
  onNumberClick: (num: number) => void;
  onUndo: () => void;
  onErase: () => void;
  onHint: () => void;
  onNewGame: () => void;
  toggleNoteMode: () => void;
  isNoteMode: boolean;
  isHintLoading: boolean;
  hintsRemaining: number;
}

const Controls: React.FC<ControlsProps> = ({
  onNumberClick,
  onUndo,
  onErase,
  onHint,
  onNewGame,
  toggleNoteMode,
  isNoteMode,
  isHintLoading,
  hintsRemaining
}) => {
  return (
    <div className="flex flex-col gap-6 w-full max-w-md mx-auto mt-6">
      
      {/* Action Row */}
      <div className="flex justify-between items-center gap-2 px-2">
         <button onClick={onUndo} className="p-3 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-700 transition-colors" title="Undo">
            <Undo2 size={20} />
         </button>
         
         <button 
          onClick={toggleNoteMode} 
          className={`p-3 rounded-full transition-colors relative border ${isNoteMode ? 'bg-primary border-primary text-white shadow-md' : 'bg-slate-200 border-transparent text-slate-700 hover:bg-slate-300'}`} 
          title="Toggle Notes"
        >
            <Pencil size={20} />
            {isNoteMode && <span className="absolute -top-1 -right-1 flex h-3 w-3"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span><span className="relative inline-flex rounded-full h-3 w-3 bg-sky-500"></span></span>}
         </button>

         <button onClick={onErase} className="p-3 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-700 transition-colors" title="Erase">
            <Eraser size={20} />
         </button>

         <button 
          onClick={onHint} 
          disabled={isHintLoading || hintsRemaining <= 0}
          className={`p-3 rounded-full transition-colors flex items-center justify-center gap-1 border ${hintsRemaining > 0 ? 'bg-accent/10 border-accent/30 text-accent hover:bg-accent/20' : 'bg-slate-200 border-transparent text-slate-400 cursor-not-allowed'}`} 
          title="Get AI Hint"
        >
            {isHintLoading ? <div className="w-5 h-5 border-2 border-accent/30 border-t-accent rounded-full animate-spin" /> : <Lightbulb size={20} />}
         </button>

         <button onClick={onNewGame} className="p-3 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-700 transition-colors" title="New Game">
            <RefreshCw size={20} />
         </button>
      </div>

      {/* Numpad */}
      <div className="grid grid-cols-9 gap-1 sm:gap-2 px-1">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
          <button
            key={num}
            onClick={() => onNumberClick(num)}
            className="aspect-square flex items-center justify-center text-xl sm:text-2xl font-bold bg-white text-primary rounded-lg border border-slate-300 hover:bg-slate-50 hover:border-primary active:scale-95 transition-all shadow-sm active:translate-y-0.5"
          >
            {num}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Controls;