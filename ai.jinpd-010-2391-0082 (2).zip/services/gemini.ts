import { GoogleGenAI, Type } from "@google/genai";
import { Board, HintResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSudokuHint = async (board: Board): Promise<HintResponse> => {
  // Convert board to simple number grid for AI
  const grid = board.map(row => row.map(cell => cell.value));
  
  // Format the grid as a readable string or JSON
  const gridStr = JSON.stringify(grid);

  const prompt = `
    You are a Grandmaster Sudoku Solver.
    Analyze the following 9x9 Sudoku grid (0 represents empty cells).
    Find the MOST LOGICAL next step. 
    Prefer simple techniques (Hidden Singles, Naked Singles) over complex ones unless necessary.
    
    Current Grid:
    ${gridStr}

    Return a JSON object identifying the cell coordinates (0-indexed row and col), the correct value, and a brief, helpful explanation of the logic used (e.g., "The number 5 is the only candidate for this cell in row 3").
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            row: { type: Type.INTEGER, description: "0-indexed row number" },
            col: { type: Type.INTEGER, description: "0-indexed column number" },
            value: { type: Type.INTEGER, description: "The correct value for the cell" },
            explanation: { type: Type.STRING, description: "Short explanation of the logic" },
          },
          required: ["row", "col", "value", "explanation"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as HintResponse;
  } catch (error) {
    console.error("Error getting hint:", error);
    throw new Error("AI is thinking too hard... try again later.");
  }
};
