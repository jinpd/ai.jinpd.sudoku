import React from 'react';
import { CellData } from '../types';

interface CellProps {
  cell: CellData;
  isSelected: boolean;
  isRelated: boolean; // Same row/col/box
  isSameValue: boolean; // Contains same number as selected
  onClick: () => void;
}

const Cell: React.FC<CellProps> = ({ cell, isSelected, isRelated, isSameValue, onClick }) => {
  const { row, col, value, isFixed, notes, isError, isHinted } = cell;

  // Grid Lines logic
  // Base: Solid black border
  const borderColor = 'border-black border-solid';
  let borderClasses = borderColor;

  // Vertical Lines (Right border)
  if (col === 8) {
    // No right border for the last cell in a row (Container handles outer edge)
  } else if ((col + 1) % 3 === 0) {
    // 3x3 Block Divider
    borderClasses += ' border-r-[6px]';
  } else {
    // Standard Cell Divider
    borderClasses += ' border-r-[4px]';
  }

  // Horizontal Lines (Bottom border)
  if (row === 8) {
    // No bottom border for the last row (Container handles outer edge)
  } else if ((row + 1) % 3 === 0) {
    // 3x3 Block Divider
    borderClasses += ' border-b-[6px]';
  } else {
    // Standard Cell Divider
    borderClasses += ' border-b-[4px]';
  }

  // Dynamic Styles for state
  let bgClass = 'bg-white';
  // Fixed numbers are pure black, User inputs are a dark primary color
  let textClass = isFixed ? 'text-black font-extrabold' : 'text-cyan-700 font-bold';
  
  if (isError) {
    bgClass = 'bg-red-100';
    textClass = 'text-red-600 font-bold';
  } else if (isSelected) {
    bgClass = 'bg-cyan-100';
  } else if (isSameValue && value !== 0) {
    bgClass = 'bg-cyan-50';
  } else if (isRelated) {
    bgClass = 'bg-slate-50';
  }

  if (isHinted) {
    bgClass = 'animate-pulse-slow bg-pink-100';
  }

  return (
    <div
      onClick={onClick}
      className={`
        relative flex items-center justify-center text-xl sm:text-3xl cursor-pointer select-none transition-colors duration-75
        h-8 w-8 sm:h-12 sm:w-12 md:h-14 md:w-14
        ${borderClasses}
        ${bgClass} ${textClass}
      `}
      role="gridcell"
      aria-label={`Row ${row + 1}, Column ${col + 1}, Value ${value === 0 ? 'Empty' : value}`}
    >
      {value !== 0 ? (
        value
      ) : (
        notes.size > 0 && (
          <div className="grid grid-cols-3 gap-[1px] w-full h-full p-0.5 pointer-events-none opacity-70">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
              <div key={n} className="flex items-center justify-center text-[8px] sm:text-[10px] leading-none text-slate-600 font-semibold">
                {notes.has(n) ? n : ''}
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
};

export default React.memo(Cell);