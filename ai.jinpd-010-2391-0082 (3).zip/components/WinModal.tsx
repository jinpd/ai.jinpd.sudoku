import React from 'react';
import { Trophy, Clock, RotateCcw } from 'lucide-react';

interface WinModalProps {
  isOpen: boolean;
  timeStr: string;
  difficulty: string;
  onNewGame: () => void;
}

const WinModal: React.FC<WinModalProps> = ({ isOpen, timeStr, difficulty, onNewGame }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white border border-slate-200 rounded-2xl p-8 max-w-sm w-full shadow-2xl transform transition-all scale-100 flex flex-col items-center text-center">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <Trophy size={40} className="text-primary animate-bounce" />
        </div>
        
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Puzzle Solved!</h2>
        <p className="text-slate-500 mb-6">Excellent mental workout.</p>

        <div className="grid grid-cols-2 gap-4 w-full mb-8">
            <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl flex flex-col items-center">
                <Clock size={20} className="text-accent mb-2" />
                <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Time</span>
                <span className="text-lg font-mono text-slate-800 font-bold">{timeStr}</span>
            </div>
            <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl flex flex-col items-center">
                <div className="text-accent font-bold text-lg mb-1">lvl</div>
                <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Difficulty</span>
                <span className="text-lg font-bold text-slate-800 capitalize">{difficulty}</span>
            </div>
        </div>

        <button 
            onClick={onNewGame}
            className="w-full py-4 bg-primary hover:bg-cyan-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-md"
        >
            <RotateCcw size={20} />
            Play Again
        </button>
      </div>
    </div>
  );
};

export default WinModal;