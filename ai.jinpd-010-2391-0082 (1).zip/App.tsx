import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Board, CellData, Difficulty, HintResponse } from './types';
import { generateSudoku, checkErrors, isBoardComplete } from './utils/sudoku';
import { getSudokuHint } from './services/gemini';
import Cell from './components/Cell';
import Controls from './components/Controls';
import WinModal from './components/WinModal';
import { BrainCircuit, Lightbulb } from 'lucide-react';

const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

const App: React.FC = () => {
  // Game State
  const [board, setBoard] = useState<Board>([]);
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.EASY);
  const [selectedCell, setSelectedCell] = useState<{ r: number; c: number } | null>(null);
  const [history, setHistory] = useState<Board[]>([]);
  const [timer, setTimer] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isNoteMode, setIsNoteMode] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  
  // AI Hint State
  const [isHintLoading, setIsHintLoading] = useState(false);
  const [hintMessage, setHintMessage] = useState<string | null>(null);
  const [hintsRemaining, setHintsRemaining] = useState(3);

  // Timer Ref
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startNewGame = useCallback((diff: Difficulty = difficulty) => {
    const newBoard = generateSudoku(diff);
    setBoard(newBoard);
    setDifficulty(diff);
    setHistory([]);
    setTimer(0);
    setIsActive(true);
    setGameWon(false);
    setHintMessage(null);
    setSelectedCell(null);
    setHintsRemaining(3);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => setTimer((t) => t + 1), 1000);
  }, [difficulty]);

  // Initial load
  useEffect(() => {
    startNewGame(Difficulty.EASY);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Handle Win Condition
  useEffect(() => {
    if (isActive && board.length > 0 && isBoardComplete(board)) {
      setGameWon(true);
      setIsActive(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  }, [board, isActive]);

  const handleCellClick = (r: number, c: number) => {
    setSelectedCell({ r, c });
    setHintMessage(null); // Clear hint on interaction
  };

  const updateBoard = (newBoard: Board) => {
    setHistory((prev) => [...prev, board]); // Push current state to history
    const validatedBoard = checkErrors(newBoard);
    setBoard(validatedBoard);
  };

  const handleNumberInput = (num: number) => {
    if (!selectedCell || !isActive || gameWon) return;
    const { r, c } = selectedCell;
    const cell = board[r][c];

    if (cell.isFixed) return;

    const newBoard = board.map((row) => row.map((c) => ({ ...c }))); // Deep copy rows/cells
    const targetCell = newBoard[r][c];

    // Remove hint highlight if touching this cell
    targetCell.isHinted = false;

    if (isNoteMode) {
      const newNotes = new Set(targetCell.notes);
      if (newNotes.has(num)) {
        newNotes.delete(num);
      } else {
        newNotes.add(num);
      }
      targetCell.notes = newNotes;
    } else {
      // If value is same, toggle off (0)
      if (targetCell.value === num) {
          targetCell.value = 0;
      } else {
          targetCell.value = num;
      }
    }

    updateBoard(newBoard);
  };

  const handleUndo = () => {
    if (history.length === 0 || !isActive) return;
    const previousBoard = history[history.length - 1];
    setBoard(previousBoard);
    setHistory((prev) => prev.slice(0, -1));
  };

  const handleErase = () => {
    if (!selectedCell || !isActive || gameWon) return;
    const { r, c } = selectedCell;
    if (board[r][c].isFixed) return;

    const newBoard = board.map((row) => row.map((c) => ({ ...c })));
    newBoard[r][c].value = 0;
    newBoard[r][c].notes = new Set();
    newBoard[r][c].isHinted = false;
    updateBoard(newBoard);
  };

  const handleHint = async () => {
    if (hintsRemaining <= 0 || isHintLoading || gameWon) return;
    setIsHintLoading(true);
    try {
        const hint: HintResponse = await getSudokuHint(board);
        
        const newBoard = board.map(row => row.map(cell => ({...cell, isHinted: false})));
        // Highlight the hinted cell
        if (newBoard[hint.row] && newBoard[hint.row][hint.col]) {
            newBoard[hint.row][hint.col].isHinted = true;
            // Select it for convenience
            setSelectedCell({ r: hint.row, c: hint.col });
            setBoard(newBoard);
            setHintMessage(hint.explanation);
            setHintsRemaining(prev => prev - 1);
        }
    } catch (e) {
        setHintMessage("Couldn't find a hint right now. Try filling more cells.");
    } finally {
        setIsHintLoading(false);
    }
  };

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (!isActive || gameWon) return;

        const num = parseInt(e.key);
        if (!isNaN(num) && num >= 1 && num <= 9) {
            handleNumberInput(num);
            return;
        }

        if (e.key === 'Backspace' || e.key === 'Delete') {
            handleErase();
            return;
        }

        if (e.key === 'z' && (e.metaKey || e.ctrlKey)) {
            handleUndo();
            return;
        }

        if(e.key === 'n') {
            setIsNoteMode(prev => !prev);
        }

        // Arrow keys navigation
        if (selectedCell) {
            let { r, c } = selectedCell;
            if (e.key === 'ArrowUp') r = Math.max(0, r - 1);
            if (e.key === 'ArrowDown') r = Math.min(8, r + 1);
            if (e.key === 'ArrowLeft') c = Math.max(0, c - 1);
            if (e.key === 'ArrowRight') c = Math.min(8, c + 1);
            setSelectedCell({ r, c });
        }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isActive, selectedCell, board, isNoteMode, gameWon]);

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center py-8 px-4 font-sans relative overflow-hidden">
      
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden opacity-5">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-accent rounded-full blur-[120px]" />
      </div>

      <header className="w-full max-w-lg flex flex-col gap-4 mb-6 z-10">
        <div className="flex justify-between items-center">
             <div className="flex items-center gap-2">
                <BrainCircuit className="text-primary" size={32} />
                <div className="flex flex-col">
                  <h1 className="text-2xl font-bold tracking-tight text-slate-900 leading-none">AI.JINPD-010-2391-0082</h1>
                  <a href="mailto:ai.jinpd@gmail.com" className="text-xs text-slate-500 font-medium hover:text-primary transition-colors">ai.jinpd@gmail.com</a>
                </div>
             </div>
             <div className="flex items-center gap-4 bg-white px-4 py-2 rounded-full border border-slate-300 shadow-sm">
                <span className="font-mono text-xl text-primary font-bold">{formatTime(timer)}</span>
             </div>
        </div>
        
        <div className="flex justify-between items-center">
            <div className="flex gap-2">
                {(Object.values(Difficulty) as Difficulty[]).map((d) => (
                    <button
                        key={d}
                        onClick={() => startNewGame(d)}
                        className={`px-3 py-1 text-sm rounded-full transition-all border ${difficulty === d ? 'bg-primary border-primary text-white font-bold shadow-md' : 'bg-white border-slate-300 text-slate-500 hover:bg-slate-50'}`}
                    >
                        {d}
                    </button>
                ))}
            </div>
            <div className="text-xs text-slate-500 flex items-center gap-1 font-medium">
                Hints: <span className={hintsRemaining > 0 ? 'text-accent font-bold text-sm' : 'text-slate-400'}>{hintsRemaining}</span>
            </div>
        </div>
      </header>

      {hintMessage && (
        <div className="w-full max-w-lg mb-4 bg-accent/10 border border-accent/20 p-4 rounded-lg flex items-start gap-3 animate-fade-in z-10">
            <Lightbulb className="text-accent shrink-0 mt-0.5" size={18} />
            <p className="text-sm text-slate-800">{hintMessage}</p>
            <button onClick={() => setHintMessage(null)} className="ml-auto text-slate-500 hover:text-slate-800">×</button>
        </div>
      )}

      <main className="z-10 w-full max-w-lg">
        <div className="bg-white p-1 sm:p-2 rounded-xl shadow-xl border border-slate-200">
            {/* 
                Grid Lines Update:
                - Container provides a full 6px border on all sides.
                - Internal block lines are 6px.
                - Standard cell lines are 4px.
            */}
            <div className="grid grid-cols-9 border-[6px] border-black">
            {board.map((row, rIndex) => (
                <React.Fragment key={rIndex}>
                {row.map((cell, cIndex) => (
                    <Cell
                    key={`${rIndex}-${cIndex}`}
                    cell={cell}
                    isSelected={selectedCell?.r === rIndex && selectedCell?.c === cIndex}
                    isRelated={selectedCell ? (selectedCell.r === rIndex || selectedCell.c === cIndex) : false}
                    isSameValue={selectedCell && board[selectedCell.r][selectedCell.c].value !== 0 ? board[selectedCell.r][selectedCell.c].value === cell.value : false}
                    onClick={() => handleCellClick(rIndex, cIndex)}
                    />
                ))}
                </React.Fragment>
            ))}
            </div>
        </div>

        <Controls 
            onNumberClick={handleNumberInput}
            onUndo={handleUndo}
            onErase={handleErase}
            onHint={handleHint}
            onNewGame={() => startNewGame()}
            toggleNoteMode={() => setIsNoteMode(!isNoteMode)}
            isNoteMode={isNoteMode}
            isHintLoading={isHintLoading}
            hintsRemaining={hintsRemaining}
        />
      </main>

      <WinModal 
        isOpen={gameWon} 
        timeStr={formatTime(timer)} 
        difficulty={difficulty}
        onNewGame={() => startNewGame()} 
      />

    </div>
  );
};

export default App;