import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react()],
    define: {
      // Vercel의 환경변수를 클라이언트 코드에서 process.env.API_KEY로 쓸 수 있게 연결
      'process.env.API_KEY': JSON.stringify(env.API_KEY)
    }
  };
});