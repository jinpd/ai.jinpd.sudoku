import { Board, CellData, Difficulty } from '../types';

// Constants
const BLANK = 0;
const SIZE = 9;

const getSafeBoard = (): number[][] => Array.from({ length: SIZE }, () => Array(SIZE).fill(BLANK));

// Check if placing num at board[row][col] is valid
export const isValid = (board: number[][], row: number, col: number, num: number): boolean => {
  // Check Row
  for (let x = 0; x < SIZE; x++) {
    if (board[row][x] === num && x !== col) return false;
  }

  // Check Col
  for (let x = 0; x < SIZE; x++) {
    if (board[x][col] === num && x !== row) return false;
  }

  // Check 3x3 Box
  const startRow = row - (row % 3);
  const startCol = col - (col % 3);
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (board[i + startRow][j + startCol] === num && (i + startRow !== row || j + startCol !== col)) {
        return false;
      }
    }
  }
  return true;
};

// Solve the board using backtracking
const solveBoard = (board: number[][]): boolean => {
  for (let row = 0; row < SIZE; row++) {
    for (let col = 0; col < SIZE; col++) {
      if (board[row][col] === BLANK) {
        // Try numbers 1-9
        const nums = [1, 2, 3, 4, 5, 6, 7, 8, 9].sort(() => Math.random() - 0.5); // Randomize for varied solutions
        for (const num of nums) {
          if (isValid(board, row, col, num)) {
            board[row][col] = num;
            if (solveBoard(board)) return true;
            board[row][col] = BLANK;
          }
        }
        return false;
      }
    }
  }
  return true;
};

// Generate a new puzzle
export const generateSudoku = (difficulty: Difficulty): Board => {
  // 1. Create a full valid board
  const rawBoard = getSafeBoard();
  
  // Fill diagonal 3x3 boxes first (they are independent)
  for (let i = 0; i < SIZE; i = i + 3) {
    fillBox(rawBoard, i, i);
  }

  // Solve the rest
  solveBoard(rawBoard);

  // 2. Remove digits based on difficulty
  let attempts = 0;
  switch (difficulty) {
    case Difficulty.EASY: attempts = 30; break;
    case Difficulty.MEDIUM: attempts = 45; break;
    case Difficulty.HARD: attempts = 55; break;
  }

  while (attempts > 0) {
    let row = Math.floor(Math.random() * SIZE);
    let col = Math.floor(Math.random() * SIZE);
    while (rawBoard[row][col] === BLANK) {
      row = Math.floor(Math.random() * SIZE);
      col = Math.floor(Math.random() * SIZE);
    }
    // Backup
    const backup = rawBoard[row][col];
    rawBoard[row][col] = BLANK;

    // Optional: Check if unique solution exists here. 
    // For this simple implementation, we assume removing random cells keeps it solvable enough for a web game context.
    // A true generator ensures uniqueness, but it's computationally heavier.
    
    attempts--;
  }

  // Convert to Board type
  return rawBoard.map((rowArr, rIdx) => 
    rowArr.map((val, cIdx) => ({
      row: rIdx,
      col: cIdx,
      value: val,
      isFixed: val !== BLANK,
      notes: new Set<number>(),
      isError: false,
    }))
  );
};

const fillBox = (board: number[][], row: number, col: number) => {
  let num: number;
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      do {
        num = Math.floor(Math.random() * 9) + 1;
      } while (!isSafeInBox(board, row, col, num));
      board[row + i][col + j] = num;
    }
  }
};

const isSafeInBox = (board: number[][], rowStart: number, colStart: number, num: number) => {
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (board[rowStart + i][colStart + j] === num) return false;
    }
  }
  return true;
};

export const checkErrors = (board: Board): Board => {
  const newBoard = board.map(row => row.map(cell => ({ ...cell, isError: false })));
  const numberBoard = board.map(row => row.map(cell => cell.value));

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const cell = newBoard[r][c];
      if (cell.value !== BLANK) {
        if (!isValid(numberBoard, r, c, cell.value)) {
          // This check is slightly recursive because isValid checks the board itself. 
          // However, isValid checks if *other* cells conflict.
          // Since we passed the board with the value already in it, we need to modify isValid check
          // OR, simpler: just iterate and find duplicates.
        }
      }
    }
  }
  
  // Explicit check for visual conflicts
  // Rows
  for (let r = 0; r < SIZE; r++) {
    const seen = new Map<number, number[]>();
    for(let c = 0; c < SIZE; c++) {
      const v = newBoard[r][c].value;
      if (v !== BLANK) {
        if (!seen.has(v)) seen.set(v, []);
        seen.get(v)?.push(c);
      }
    }
    seen.forEach((cols, val) => {
      if (cols.length > 1) {
        cols.forEach(c => newBoard[r][c].isError = true);
      }
    });
  }
  // Cols
  for (let c = 0; c < SIZE; c++) {
    const seen = new Map<number, number[]>();
    for(let r = 0; r < SIZE; r++) {
      const v = newBoard[r][c].value;
      if (v !== BLANK) {
        if (!seen.has(v)) seen.set(v, []);
        seen.get(v)?.push(r);
      }
    }
    seen.forEach((rows, val) => {
      if (rows.length > 1) {
        rows.forEach(r => newBoard[r][c].isError = true);
      }
    });
  }
  // Boxes
  for (let br = 0; br < 3; br++) {
    for (let bc = 0; bc < 3; bc++) {
      const seen = new Map<number, {r:number, c:number}[]>();
      for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
          const r = br * 3 + i;
          const c = bc * 3 + j;
          const v = newBoard[r][c].value;
          if (v !== BLANK) {
             if (!seen.has(v)) seen.set(v, []);
             seen.get(v)?.push({r, c});
          }
        }
      }
      seen.forEach((coords, val) => {
        if (coords.length > 1) {
          coords.forEach(({r, c}) => newBoard[r][c].isError = true);
        }
      });
    }
  }

  return newBoard;
}

export const isBoardComplete = (board: Board): boolean => {
    for(let r=0; r<SIZE; r++){
        for(let c=0; c<SIZE; c++){
            if(board[r][c].value === BLANK || board[r][c].isError) return false;
        }
    }
    return true;
}
